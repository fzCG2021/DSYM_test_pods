//
//  TestApp.swift
//  Test
//
//  Created by sonali.chawla on 7/2/21.
//

import SwiftUI

@main
struct TestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
